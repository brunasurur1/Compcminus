#ifndef AST_H
#define AST_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ASTNode {
    char *type;                // "Program", "VarDecl", "FunDecl", etc.
    char *value;               // nome do ID, valor numérico em string, etc.
    struct ASTNode *child;     // primeiro filho
    struct ASTNode *sibling;   // próximo irmão
} ASTNode;

ASTNode* newASTNode(const char *type);
void setNodeVal(ASTNode *node, const char *val);
void setNodeType(ASTNode *node, const char *type);
void addChild(ASTNode *parent, ASTNode *child);
ASTNode* addSibling(ASTNode *node, ASTNode *sib);
void printAST(ASTNode *root);

#ifdef __cplusplus
}
#endif

#endif
