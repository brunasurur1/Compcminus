#ifndef SYMBOLTABLE_H
#define SYMBOLTABLE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Symbol {
    char *name;             // nome do identificador
    char *type;             // tipo (int, void, etc.)
    char *scope;            // escopo (nome da função ou "global")
    struct Symbol *next;
} Symbol;

void initSymbolTable();
void printSymbolTable();
void insertSymbol(const char *name, const char *type, const char *scope);
int  lookupSymbol(const char *name);

// Gerenciamento de escopos
void pushScope(const char *scopeName);
void popScope();
const char* getCurrentScope();

#ifdef __cplusplus
}
#endif

#endif
