#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symboltable.h"

static Symbol *symbolTable = NULL; // lista ligada de símbolos

// Pilha de escopos (simples para exemplo)
#define MAX_SCOPE_DEPTH 100
static char *scopeStack[MAX_SCOPE_DEPTH];
static int scopeTop = -1;

void initSymbolTable() {
    symbolTable = NULL;
    scopeTop = -1;
    pushScope("global");
}

void printSymbolTable() {
    printf("\n--- Tabela de Símbolos ---\n");
    Symbol *ptr = symbolTable;
    while (ptr != NULL) {
        printf("Nome: %s, Tipo: %s, Escopo: %s\n",
               ptr->name, ptr->type, ptr->scope);
        ptr = ptr->next;
    }
    printf("--------------------------\n");
}

void insertSymbol(const char *name, const char *type, const char *scope) {
    // Verifica se já existe símbolo com esse nome e escopo (depende da política)
    Symbol *s = (Symbol *)malloc(sizeof(Symbol));
    s->name = strdup(name);
    s->type = strdup(type);
    s->scope = strdup(scope);
    s->next = symbolTable;
    symbolTable = s;
}

int lookupSymbol(const char *name) {
    Symbol *ptr = symbolTable;
    while (ptr != NULL) {
        if (strcmp(ptr->name, name) == 0) {
            return 1; // encontrado
        }
        ptr = ptr->next;
    }
    return 0; // não encontrado
}

void pushScope(const char *scopeName) {
    if (scopeTop < MAX_SCOPE_DEPTH - 1) {
        scopeTop++;
        scopeStack[scopeTop] = strdup(scopeName);
    } else {
        fprintf(stderr, "Scope stack overflow!\n");
    }
}

void popScope() {
    if (scopeTop >= 0) {
        free(scopeStack[scopeTop]);
        scopeStack[scopeTop] = NULL;
        scopeTop--;
    } else {
        fprintf(stderr, "Scope stack underflow!\n");
    }
}

const char* getCurrentScope() {
    if (scopeTop >= 0) {
        return scopeStack[scopeTop];
    }
    return "unknown";
}
