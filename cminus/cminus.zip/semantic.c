#include <stdio.h>
#include "semantic.h"
#include "symboltable.h"
#include "ast.h"

void checkNode(/* parâmetros */) {
    // Exemplo de função para checar um nó da árvore
}
