#ifndef SEMANTIC_H
#define SEMANTIC_H

#ifdef __cplusplus
extern "C" {
#endif

// Declarar funções para verificação de tipos, escopos, etc.
void checkNode(/* parâmetros */);

#ifdef __cplusplus
}
#endif

#endif
