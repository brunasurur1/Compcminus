#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

ASTNode* newASTNode(const char *type) {
    ASTNode *node = (ASTNode*)malloc(sizeof(ASTNode));
    node->type = strdup(type);
    node->value = NULL;
    node->child = NULL;
    node->sibling = NULL;
    return node;
}

void setNodeVal(ASTNode *node, const char *val) {
    if (node->value) free(node->value);
    node->value = strdup(val);
}

void setNodeType(ASTNode *node, const char *type) {
    if (node->type) free(node->type);
    node->type = strdup(type);
}

void addChild(ASTNode *parent, ASTNode *child) {
    if (!parent || !child) return;
    if (!parent->child) {
        parent->child = child;
    } else {
        // Adiciona ao final da lista de filhos
        ASTNode *temp = parent->child;
        while (temp->sibling) {
            temp = temp->sibling;
        }
        temp->sibling = child;
    }
}

ASTNode* addSibling(ASTNode *node, ASTNode *sib) {
    if (!node) return sib;
    ASTNode *temp = node;
    while (temp->sibling != NULL) {
        temp = temp->sibling;
    }
    temp->sibling = sib;
    return node;
}

static void printASTAux(ASTNode *root, int level) {
    if (root == NULL) return;
    for (int i = 0; i < level; i++) {
        printf("  "); // Indentação
    }
    printf("%s", root->type);
    if (root->value) {
        printf("(%s)", root->value);
    }
    printf("\n");

    printASTAux(root->child, level + 1);
    printASTAux(root->sibling, level);
}

void printAST(ASTNode *root) {
    printf("\n--- Árvore Sintática (AST) ---\n");
    printASTAux(root, 0);
    printf("--------------------------------\n");
}
